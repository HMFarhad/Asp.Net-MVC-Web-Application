﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FKM_Diagnostic_Center.Controllers
{
    public class TestController : Controller
    {
        public ActionResult Index()
        {
            UserDBContext context = new UserDBContext();
            return View(context.Tests.ToList());
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create([Bind(Include="testName, testBill")] Test t)
        {
            if (ModelState.IsValid)
            {
                UserDBContext context = new UserDBContext();
                t.testDate = DateTime.Now;
                t.testQuantity = 0;
                context.Tests.Add(t);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(t);
            }
        }

        [HttpGet]
         public ActionResult Edit(int id)
        {
            UserDBContext context = new UserDBContext();
            Test t = context.Tests.SingleOrDefault(d => d.testId == id);
            return View(t);
        }

        [HttpPost, ActionName("Edit")]
        public ActionResult Do_Edit(int id)
        {
            UserDBContext context = new UserDBContext();
            Test t = context.Tests.SingleOrDefault(d => d.testId == id);
            TryUpdateModel(t, new string[] { "testBill", "testName" });
            if (ModelState.IsValid)
            {
                t.testDate = DateTime.Now;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(t);
            }
        }
        [HttpGet]
        public ActionResult Details(int Id)
        {
            UserDBContext context = new UserDBContext();
            Test test = context.Tests.SingleOrDefault(t => t.testId == Id);
            return View(test);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            UserDBContext context = new UserDBContext();
            Test t = context.Tests.SingleOrDefault(d => d.testId == id);
            return View(t);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult Confirm_Delete(int id)
        {
            UserDBContext context = new UserDBContext();
            Test t = context.Tests.SingleOrDefault(d => d.testId == id);
            context.Tests.Remove(t);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}