﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FKM_Diagnostic_Center.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/

        [HttpGet]
        public ActionResult Index() //login
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(User user)
        {
            try
            {
                using (UserDBContext context = new UserDBContext())
                {
                    var usr = context.Users.Single(u => u.username == user.username && u.password == user.password);
                    if (usr != null)
                    {
                        Session["UserID"] = usr.id.ToString();
                        Session["Username"] = usr.username.ToString();
                        Session["Usertype"] = usr.type.ToString();
                        if(usr.type == "admin")
                        {
                            return RedirectToAction("List", "User");
                        }
                        else
                        {
                            return RedirectToAction("Index", "Employee");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError(" ", "Username or Password is wrong");
                    }
                }
            }
            catch(Exception)
            {
                return View();
            }
            return View("LogAdmin");
        }
       
        public ActionResult LogAdmin()
        {
            if (Session["UserID"]!= null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult LogUser()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult List()
        {
            UserDBContext context = new UserDBContext();
            return View(context.Users.ToList());
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(User u)
        {
            if (ModelState.IsValid)
            {
                UserDBContext context = new UserDBContext();
                context.Users.Add(u);
                context.SaveChanges();
                return RedirectToAction("List");
            }
            else
            {
                return View(u);
            }
        }
        public ActionResult Edit(int id)
        {
            UserDBContext context = new UserDBContext();
            User user = context.Users.SingleOrDefault(u => u.id == id);
            return View(user);
        }

        [HttpPost, ActionName("Edit")]
        public ActionResult Do_Edit(int id)
        {
            UserDBContext context = new UserDBContext();
            User user = context.Users.SingleOrDefault(u => u.id == id);
            if (ModelState.IsValid)
            {
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(user);
            }
        }
    }
}
